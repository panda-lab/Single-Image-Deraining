function score = niqe(img)

    load modelparameters.mat;

    blocksizerow    = 96;
    blocksizecol    = 96;
    blockrowoverlap = 0;
    blockcoloverlap = 0;
    
    score = computequality(img, blocksizerow, blocksizecol, ...
                           blockrowoverlap, blockcoloverlap, ...
                           mu_prisparam, cov_prisparam);
    
	%score = -score; % reverse
end