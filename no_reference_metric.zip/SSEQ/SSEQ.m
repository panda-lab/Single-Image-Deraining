function score = SSEQ( imdist )
    
    addpath(genpath('libsvm-3.20'));
    
    feature=feature_extract(imdist,3);
    score=SSQA_by_f(feature);
    
    score = -score + 100; % convert to 100 for the best, 0 for the worst
end

