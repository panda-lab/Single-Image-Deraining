
clc;
clear;


rain_dir = '/home/syan/workspace/CVPR19/CVPR19/synthetic/RainMist/JORDER/';
norain_dir = '/home/syan/workspace/CVPR19/CVPR19/synthetic/RainMist/JORDER/';
    
files=dir([rain_dir, '*.jpg']);
norain_files=dir([norain_dir, '*.jpg']);


SS = 0;
BL = 0;
NI = 0;
for i=1:100
    image_name = [rain_dir, files(i).name];
    input = imread(image_name);
    gt = imread([norain_dir, norain_files(i).name]);
	
	SSEQ = no_reference_metric(input, gt, 'SSEQ');
    BLIINDS2 = no_reference_metric(input, gt, 'BLIINDS2');
	NIQE = no_reference_metric(input, gt, 'NIQE');
    
	display(SSEQ);

    display(BLIINDS2);
    
    display(NIQE)
    
    SS = SS + SSEQ;
    BL = BL + BLIINDS2;
    NI = NI + NIQE;

end

SS = SS / 100;
BL = BL / 100;
NI = NI / 100;

display(SS);

display(BL);

display(NI);

 


