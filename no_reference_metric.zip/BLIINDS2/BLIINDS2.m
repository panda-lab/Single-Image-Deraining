function score = BLIINDS2(img)
    
    features = bliinds2_feature_extraction(img);
    score = bliinds_prediction(features);
    
    score = -score + 100; % convert to 100 for the best, 0 for the worst
end
