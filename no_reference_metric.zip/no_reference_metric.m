function quality = no_reference_metric(deblur_img, blur_img, metric)

    fprintf('Extract %s score...\n', metric);
    
    main_dir = pwd;
    metric_dir = fullfile('../', 'no_reference_metric', metric);
    
    
    if( strcmp(metric, 'BRISQUE') )
        
        deblur_img = rgb2gray(deblur_img);
        
        cd(metric_dir);
        quality = brisque(deblur_img);
        cd(main_dir);
    
    elseif( strcmp(metric, 'BRISQUE2') )
        
        deblur_img2 = rgb2gray(deblur_img);
        
        cd(metric_dir);
        quality = brisque(deblur_img2);
        cd(main_dir);
    
    elseif( strcmp(metric, 'DIVINE') )
        
        deblur_img = rgb2gray(deblur_img);
        
        cd(metric_dir);
        quality = divine(deblur_img);
        cd(main_dir);
        
    elseif( strcmp(metric, 'NIQE') )
        
        deblur_img2 = rgb2gray(deblur_img);
        
        cd(metric_dir);
        quality = niqe(deblur_img2);
        cd(main_dir);
    
    elseif( strcmp(metric, 'SSEQ') )
        
        deblur_img2 = rgb2gray(deblur_img);
        
        cd(metric_dir);
        quality = SSEQ(deblur_img2);
        cd(main_dir);
    
    elseif( strcmp(metric, 'BLIINDS2') )
        
        deblur_img2 = rgb2gray(deblur_img);
        
        cd(metric_dir);
        quality = BLIINDS2(deblur_img2);
        cd(main_dir);

    elseif( strcmp(metric, 'CORNIA') )
        
        if( ~isunix )
            error('CORNIA can only be used under linux OS.');
        end
        
        deblur_img = rgb2gray(deblur_img);
        
        cd(metric_dir);
        quality = get_CORNIA(deblur_img);
        cd(main_dir);
    
    elseif( strcmp(metric, 'Liu') )
        
        cd(metric_dir);
        
        deblur_img = im2double(deblur_img);
        blur_img   = im2double(blur_img);
        quality = liu_blur_metric(deblur_img, blur_img);
        
        cd(main_dir);
            
    else
        error('Unknown no-reference metric %s.', metric);
    end

end
